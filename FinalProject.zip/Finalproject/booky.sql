-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 27 avr. 2023 à 19:48
-- Version du serveur :  10.4.19-MariaDB
-- Version de PHP : 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `booky`
--

-- --------------------------------------------------------

--
-- Structure de la table `likes`
--

CREATE TABLE `likes` (
  `id_post` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `nblikes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `likes`
--

INSERT INTO `likes` (`id_post`, `id_user`, `nblikes`) VALUES
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(46, 16, 1),
(47, 16, 1),
(49, 16, 1),
(46, 17, 1);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id_message` int(10) NOT NULL,
  `author` int(10) NOT NULL,
  `post` int(10) NOT NULL,
  `contenu` varchar(255) NOT NULL,
  `date_msg` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id_message`, `author`, `post`, `contenu`, `date_msg`) VALUES
(16, 15, 46, 'Nam quis nulla. Integer malesuada.', '0000-00-00'),
(17, 16, 46, 'Sed vel lectus.', '0000-00-00'),
(18, 16, 47, ' Etiam quis quam', '0000-00-00'),
(19, 16, 47, 'Maecenas aliquet accumsan', '0000-00-00'),
(20, 16, 46, 'Nullam dapibus fermentum', '0000-00-00'),
(21, 16, 48, 'vel sagittis velit mauris v', '0000-00-00'),
(22, 14, 46, 'hhhhhhhhh', '2023-04-27'),
(23, 14, 51, 'jaime', '2023-04-27'),
(24, 14, 48, 'c vraiment interessant', '2023-04-27'),
(25, 17, 46, 'c bien j aime trop', '2023-04-27'),
(26, 17, 46, 'okay', '2023-04-27');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id_post` int(10) NOT NULL,
  `author` int(10) NOT NULL,
  `contenu` varchar(3000) NOT NULL,
  `datepost` date NOT NULL DEFAULT current_timestamp(),
  `imageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id_post`, `author`, `contenu`, `datepost`, `imageURL`) VALUES
(46, 14, 'Nam quis nulla. Integer malesuada. In in enim a arcu imperdiet malesuada. Sed vel lectus. Donec odio urna, tempus molestie, porttitor ut, iaculis', '2023-04-27', '../views/uploads1/6449a24666c57-Couple-banc-jardin-Luxembourg-630x405-C-Thinkstock.jpg'),
(47, 14, 'Etiam posuere quam ac quam. Maecenas aliquet accumsan leo. Nullam dapibus fermentum ipsum. Etiam quis quam. Integer lacinia. Nulla est. Nulla turpis m', '2023-04-27', '../views/uploads1/6449a3300b49f-istockphoto-517188688-612x612.jpg'),
(48, 15, 'Praesent in mauris eu tortor porttitor accumsan. Mauris suscipit, ligula sit amet pharetra semper, nibh ante cursus purus, vel sagittis velit mauris v', '2023-04-27', '../views/uploads1/6449a494abced-railway-hdr-1361893.jpg'),
(49, 16, 'Etiam posuere quam ac quam. Maecenas aliquet accumsan leo. Nullam dapibus fermentum ipsum. Etiam quis quam. Integer lacinia. Nulla est.', '2023-04-27', '../views/uploads1/6449a7db43bc3-nature-3082832__480.jpg'),
(51, 14, '', '2023-04-27', '../views/uploads1/6449b5e5e1aa0-WhatsApp Image 2022-04-13 at 22.21.20.jpeg'),
(52, 14, 'Nam quis nulla. Integer malesuada. In in enim a arcu imperdiet malesuada. Sed vel lectus. Donec odio urna, tempus molestie, porttitor ut, iaculis', '2023-04-27', '../views/uploads1/6449b72136bea-tete_v2f_4.jpg'),
(53, 17, 'hello this is first essai ', '2023-04-27', '../views/uploads1/6449bdd722bd0-2023-04-13.png');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(10) NOT NULL,
  `nom_user` varchar(80) NOT NULL,
  `birthdate` date NOT NULL,
  `pasword` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatarURL` varchar(255) DEFAULT NULL,
  `fav_book` varchar(50) DEFAULT NULL,
  `fav_author` varchar(80) DEFAULT NULL,
  `bio` varchar(200) DEFAULT NULL,
  `pays` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `nom_user`, `birthdate`, `pasword`, `email`, `avatarURL`, `fav_book`, `fav_author`, `bio`, `pays`) VALUES
(14, 'laura', '1989-12-15', '202cb962ac59075b964b07152d234b70', 'laura@gmail.com', 'uploads/6449a3c9ed843-gettyimages-1235058000-1024x1024.jpg', 'Les misérables', 'Victor Hugo', 'Amateur de livres passionné de découvertes.', 'France'),
(15, 'Emile', '1999-01-01', '202cb962ac59075b964b07152d234b70', 'emile@gmail.com', '../imgs/user.png', 'The Old Man and the Sea', 'Ernest Hemingway', 'I love eating and reading', 'London'),
(16, 'Franco', '1983-12-03', '202cb962ac59075b964b07152d234b70', 'franco@gmail.com', 'uploads/6449a83d6b7c7-ava3.webp', 'Pride and Prejudice', 'Jane Austen', 'Fervent follower of diligent reading', 'America'),
(17, 'James', '2023-04-05', '81dc9bdb52d04dc20036dbd8313ed055', 'sonko@gmail.com', 'uploads/644a93abc4fce-6449b5c8965f3-date3.jpg', 'loo', 'monaliva', 'mytitle', 'liban');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_message`),
  ADD KEY `author` (`author`),
  ADD KEY `post` (`post`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id_post`),
  ADD KEY `author` (`author`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_message` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id_post` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`author`) REFERENCES `users` (`id_user`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`post`) REFERENCES `posts` (`id_post`);

--
-- Contraintes pour la table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`author`) REFERENCES `users` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
