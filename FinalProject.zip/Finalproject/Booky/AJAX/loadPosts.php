
<?php
    include ('../dbfonctions.php');
    Connection();
    
    $searchBarValue = $_GET["var"];
    // echo 'Suggestions : <i>';

    if ($searchBarValue != "") {
        $queryID = "SELECT id_user FROM users WHERE LOWER(nom_user) LIKE LOWER('$searchBarValue%')";
        $resultID = $conn->query($queryID);
        if($resultID->num_rows == 0){
            echo "'(pas de suggestion pour le texte actuel)'";
        }else{
            $rowID = mysqli_fetch_assoc($resultID);
            $userID = $rowID['id_user'];
            // $query = "SELECT * FROM `posts` WHERE author = $userID";
        $query = "SELECT * FROM `posts`, users WHERE author = $userID and author = users.id_user";
        $result = $conn->query($query);

        if ( $result->num_rows > 0) {
            $_SESSION["uniq"]= 1;
            while( $row = $result->fetch_assoc() ){
                $contenu = $row["contenu"];
                $image = $row["imageURL"];
                $username = $row["nom_user"];
                $date = $row["datepost"];
            $avatar = $row["avatarURL"];
                $id_post = $row["id_post"];
                $tmp = explode("/", $image);
                $img = end($tmp);
                $nbrMSG =Nombre_de_comments($id_post);
            ?>
     
        <div class="post" id="suggestions">
                <div class="avatarDiv">
                    <a href="">
                        <div class="avatar">
                            <img src="<?php echo $avatar?>" alt="">
                        </div>
                    </a>
                </div>
        
                <div class="contentPost">
                    <div class="postInfo">
                        <div class="postClick" value="id_post">
                            <p class="username"><?php echo $username?> <span>-  <?php echo $date?></span> </p>
        
                            <p class="postDescription">
                                <?php echo $contenu?>
                            </p>
    
                            <!-- <div class="postPic">
                                <img src="../user_data/<?php //echo $userID;?>/<?php //echo $img;?>" alt="">
                            </div> -->
                            <?php
                                if ($image) {
                                   ?> <div class="postPic">
                                        <img src="<?php echo $image; ?>" alt="">
                                    </div>
                                    <?php }
                            
                            ?>
                        </div>
    
                        <div class="display">
                            <div class="cmntTypeDiv">
                                <div class="profil">
                                    <div class="profileAvatar"></div>
                                </div>
                                <div class="typeCmnt">
                                    <form action="../pageparts/addComment.php?id_post=<?php echo $id_post;?>">
                                        <textarea class="cmntTextarea" name="msg" placeholder="Laissez un commentaire ..."></textarea> <br>
                                        <button class="submit" disabled>Répondre</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="reactPost">
                            <div class="prince">
                                    <form method="post" action="../pageparts/Likes.php?postID=<?php echo $id_post?>" >
                                        <div class="reactCardLove">
                                            <div class="reactIcon heartDiv">
                                                <button  id="btnLikes" type="submit"><i class='bx bx-heart' ></i></button>
                                                <input type="hidden" name="like" id="hiddenPost" value="<?php echo $id_post?>">
                                            </div>
                                            <div class="desc">
                                                <p id="nbrLikes" style="text-decoration: none; font-weight: 700"><?php 
                                                    echo NbLikesPost($id_post);
                                                ?>
                                                </p>
                                            </div>
                                        </div>

                                    </form>
                                   
                                <a style="color: black; text-decoration: none; font-weight: 800" href="<?php if(isset($_COOKIE["username"])) { echo "./pagepost.php?id_post=$id_post"; } else { echo "./login.php"; } ?>">
                                    <div class="reactCardCmnt">
                                        <div class="cmntDiv reactIcon">
                                            <!-- <form action="./pageparts/getpostID.php?id_post=<?php //echo $id_post;?>"> -->
                                            <button class="cmntIcon"><i id="cmntIcon" class='bx bx-message-rounded'></i></button>
                                            <!-- </form> -->
                                        </div>
                                        <div class="desc">
                                            <p><?php
                                                    echo $nbrMSG;
                                                ?></p>
                                        </div>
                                    </div>
    
                                </a>
                                <div class="reactCardWrite">
                                    <div class="writeDiv reactIcon">
                                        <button class="writeIcon"><i class='bx bx-comment-edit'></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
        </div>
               <?php }

        
        
        
        }
        else {
            echo '(pas de suggestion pour le texte actuel)';
        }
    }}
    else{
        // echo '(tapez quelque chose pour en avoir!)';
        ShowPosts();
    }

    // echo '</i>';
?>

<!-- <div class="post" id="suggestions">
                    <div class="avatarDiv">
                        <a href=""><div class="avatar">
                               <img src="../imgs/mouad.jpeg" alt=""> 
                            </div>
                        </a>    
                    </div>
    
                    <div class="content">
                        <div class="postInfo">
                            <p class="username"><span>-  </span> </p>
    
                            <p class="postDescription">
                            </p>
    
                            <div class="postPic">
                                <img src="../imgs/mouadAgain.jpeg" alt="">
                            </div>
    
                            <div class="display">
                                <div class="cmntTypeDiv">
                                    <div class="profil">
                                        <div class="profileAvatar"></div>
                                    </div>
                                    <div class="typeCmnt">
                                        <form action="">
                                            <textarea class="cmntTextarea" name="" placeholder="Laissez un commentaire ..."></textarea> <br>
                                            <button class="submit" disabled>Répondre</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="reactPost">
                            <div class="prince">
                                <div class="reactCardLove">
                                    <div class="reactIcon heartDiv">
                                        <button><i class='bx bx-heart' ></i></button>
                                    </div>
                                    <div class="desc">
                                        <p>56</p>
                                    </div>
                                </div>
                                
                                <div class="reactCardCmnt">
                                    <div class="cmntDiv reactIcon">
                                        <button class="cmntIcon"><i id="cmntIcon" class='bx bx-message-rounded'></i></button>
                                    </div>
                                    <div class="desc">
                                        <p>56</p>
                                    </div>
                                </div>
    
                                <div class="reactCardWrite">
                                    <div class="writeDiv reactIcon">
                                        <button class="writeIcon"><i class='bx bx-comment-edit'></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div> -->