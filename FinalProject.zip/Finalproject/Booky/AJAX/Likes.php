<?php 
include("../dbfonctions.php");
Connection();



$postID = $_GET["id_post"];
$userID = GetUserId();
if(isset($_POST["like"])){

    $query = "SELECT * FROM likes WHERE id_post = $postID AND id_user = $userID";
    $result = $conn->query($query);
    if ($result->num_rows === 0) {
        $query = "INSERT INTO likes VALUES ($postID, $userID, 1)";
        $resultatt = $conn->query($query);
        if($resultatt){
            $req = "SELECT SUM(nblikes) as num_likes FROM likes WHERE id_post = $postID";
            $res = $conn->query($req);
            $row = $res->fetch_assoc();
            $nblikes = $row["num_likes"];
            if($nblikes == NULL){
            return 0;
            }
            return $nblikes;
        }

        
    }else{
        $row = $result->fetch_assoc();
        if ($row['nblikes'] == 1) {
            // echo "helo";

            $query = "DELETE FROM likes WHERE id_post = $postID AND id_user = $userID";
            // echo"$query";
            $resultattt = $conn->query($query);
            if($resultattt){
                $req = "SELECT SUM(nblikes) as num_likes FROM likes WHERE id_post = $postID";
                $res = $conn->query($req);
                $row = $res->fetch_assoc();
                $nblikes = $row["num_likes"];
                if($nblikes == NULL){
                return 0;
                }
                return $nblikes;
            }
        }
    }
}

?>