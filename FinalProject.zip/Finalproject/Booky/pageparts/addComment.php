<?php

use FTP\Connection;

include('../dbfonctions.php');
Connection();
$date = date("y-m-d");

$userID = GetUserId();
$id_post = $_GET["id_post"];
$ind = $_GET["pp"];

if(isset($_POST["msg"])){
    // echo $date;

    if ($_COOKIE['username']) {
        $contenu = $_POST["msg"];
        $req = "INSERT INTO messages VALUES (NULL, $userID, $id_post, '$contenu', CURRENT_TIMESTAMP())";
        $res = $conn->query($req);
        if($res && $ind){
            header("location:../views/pagepost.php?id_post=$id_post");
        } else if ($res){
            header("location:../views/index.php?userID=$userID");
        }
    } else {
        header("location:../views/login.php");
    }

    // header("location:./")
}
?>