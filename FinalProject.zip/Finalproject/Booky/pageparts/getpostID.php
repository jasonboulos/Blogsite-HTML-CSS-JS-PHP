<?php 
session_start();
include('../dbfonctions.php');
$userID = GetUserId();
$id_post = $_GET["id_post"];
$_SESSION["id_post"]= $id_post;
header("location:../views/index.php?userID=$userID")
?>