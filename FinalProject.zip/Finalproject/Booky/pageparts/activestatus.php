<?php 

$userID =  GetUserId();
$info = GetInfos($userID);
?>

<head>
    <link rel="stylesheet" href="../css/activestatus.css">
</head>
<?php



            
                $username = $info["username"];
                
           
                
                ?>     <a href="./profile.php?userID=<?php echo $userID?> "><div class="useractive">
                <img src="<?php echo $info["avatarURL"]?>" alt="">
                <div class = "infos">
                    <p class="user_name"><?php echo $username ?></p>
                    <div class = "bot">
                         <div class="isactive"></div>
                         <p class="active">Active</p>

                    </div>
                
                    
                    
                </div>

             </div></a>
             <div class="navBar">
                        <a href="./index.php?userID=<?php echo $userID?>"><div id="home" class="link"> <button><i class='bx bx-book-reader'></i> Home</button> </div></a>
                        <a href="./User_infos.php?userID=<?php echo $userID?>"><div class="link"> <button><i class='bx bx-cog'></i> Parametres</button></div></a>
                        <a href="./profile.php?userID=<?php echo $userID?>"><div class="link"> <button><i class='bx bx-face' ></i> Profile</button></div></a>
                        <a href="./profile.php?userID=<?php echo $userID?>"><div class="crePost"><button> Partagez votre recommandation!</button></div></a>
                    </div>
             
                
                
                
                
                <?php 
                if(isset($_COOKIE["username"])){
                ?> 
                <form action = "#" method="post">
                 <!-- <input class="logoutbtn" type="submit" name="" id="" value="logout"><box-icon name='log-out' animation='tada' flip='vertical' ></box-icon></input> -->
                 <button class="logoutbtn" ><span class="mi">Logout <box-icon name='log-out' animation='tada' flip='vertical' ></box-icon></span></button>
                 <input type="hidden" name = "logout" value = "ok">
                </form>
               
     <?php
                }
                
                ?>
                
     

            

             