<?php

use FTP\Connection;

include('../dbfonctions.php');
$contenu = $_POST["contenu"];
// $dateFormat = 'y-m-d';
// $date = date($dateFormat);
$userID = $_GET["userID"];
Connection();
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the file was uploaded without errors
    if (isset($_FILES["f"]) && $_FILES["f"]["error"] == 0) {
        // Check the file size
        if ($_FILES["f"]["size"] > 5000000) {
            echo "Sorry, your file is too large. Please upload a file that is less than 5MB.";
        } else {
            // Define the directory where the image will be stored
            $target_dir = "../views/uploads1/";
            // Generate a unique filename for the image to avoid overwriting existing files
            $filename = uniqid() . "-" . basename($_FILES["f"]["name"]);
            // Define the full path to the image file on the server
            $target_file = $target_dir . $filename;
            // echo $target_file;
            // Move the uploaded image to the target directory
            $filetmpname = $_FILES["f"]["tmp_name"];
            if (move_uploaded_file($filetmpname, $target_file)) {
                // Save the file path to the database for later retrieval
                // Replace this with your own code to insert the file path into your database

                $req = "INSERT INTO posts VALUES (NULL, $userID, '$contenu', CURRENT_TIMESTAMP(), '$target_file')";
                $result = $conn->query($req);
                header("location:../views/profile.php?userID=$userID");
        


            } else {
                // Display an error message if the file could not be moved
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        // Display an error message if the file was not uploaded
        $req = "INSERT INTO posts VALUES (NULL, $userID, '$contenu', CURRENT_TIMESTAMP(), null)";
                $result = $conn->query($req);
                header("location:../views/profile.php?userID=$userID");
    }
}
?>
