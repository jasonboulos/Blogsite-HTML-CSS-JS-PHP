<?php 
include("../dbfonctions.php");
Connection();
global $conn;


$postID = $_GET["postID"];
$userID = GetUserId();
if(isset($_POST["like"])){
    ?><input type="hidden" value="clicked" ><?php
    if ($_COOKIE['username']) {
        $query = "SELECT * FROM likes WHERE id_post = $postID AND id_user = $userID";
        $result = $conn->query($query);
        if ($result->num_rows === 0) {
            $query = "INSERT INTO likes VALUES ($postID, $userID, 1)";
            $conn->query($query);
        }else{
            $row = $result->fetch_assoc();
            if ($row['nblikes'] == 1) {
                // echo "helo";

                $query = "DELETE FROM likes WHERE id_post = $postID AND id_user = $userID";
                echo"$query";
                $conn->query($query);
            }
        }
    } else {
        header("location:../views/login.php");
    }
    
}

if($_GET["location"]){
    $userIID = $_GET["userID"];
    header("location:../views/profile.php?userID=$userIID");
}else{
    if ($_COOKIE['username']) { 
        header("location:../views/index.php?userID=$userID#$postID"); 
    } else { 
        header("location:../views/login.php");
    };
}


?>