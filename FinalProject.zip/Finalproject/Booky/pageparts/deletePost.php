<?php
session_start();

// use FTP\Connection;

include('../dbfonctions.php');
Connection();
// $userID = GetUserId();
$id_post = $_GET["id_post"];

$rq = "SELECT imageURL FROM posts where id_post = $id_post";
$res1 = $conn->query($rq);
$rowID = mysqli_fetch_assoc($res1);
$image = $row['imageURL'];
if($image) unlink($image);

$userID = GetUserId();
$msgdel = "DELETE FROM messages where post =  $id_post";
$resmsgdel= $conn->query($msgdel);
$req = "DELETE FROM posts where id_post = $id_post";
$res2 = $conn->query($req);

$_SESSION["deletemsg"] = "Le post a été bien supprimé";



// setcookie("AlertDelete", "le post est bien supprimé", time() + 5);



header("location:../views/profile.php?userID=$userID");
?>