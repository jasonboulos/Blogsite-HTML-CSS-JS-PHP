<?php
include("../dbfonctions.php");
connection();
$loginStatus = CheckLogin();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="icon" type="image/x-icon" href="../imgs/B.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Open+Sans&family=Raleway:wght@500&family=Roboto+Slab:wght@500&family=Rubik&family=Ubuntu:ital@0;1&display=swap" rel="stylesheet">
    <title>Booky | Login</title>
</head>
<body>
    <div class="container" id="container">
        <div class="left">
            <video width="100%" height="99.97%" autoplay muted loop>
                <source src="../imgs/bg2.mp4" type="video/mp4">
                    Your browser does not support the video tag.
            </video>

            <div class="bord c">
			    <div class="title">Connectez-vous à votre <br> compte!</div>
                <?php
                   if ( $loginStatus["Successful"] ) {
                    $userID = $loginStatus["userID"];
                    $redirect = "Location:http://localhost/Booky/views/index.php?userID=".$userID;
                    header($redirect);
                    }
                    else{
                        $error =$loginStatus["ErrorMessage"];
                        echo "<p class = 'errorMessage'>$error</p>";
                      
                    } 
                ?>
			        <form class="form" method="post">
				        <input id = "username" type="text" name="username" placeholder="Nom d'utilisateur">
				        <input id = "password" type="password" name="mdp" placeholder="Mot de passe">
				        <button id = "login-btn" class="btn" type="submit">Connexion</button>
			        </form>
                    <div class="linkSignup">
                        <a href="./signup.php">Nouveauté sur Booky ?</a>
                    </div>
            </div>
        </div>

        <div class="right">
            <div class="logo">
                <a href="./index.php"><img src="../imgs/logoCarre.png" alt=""></a>
                <p>Your virtual safe <span>place</span> to share your <span>words</span></p>
            </div>
        </div>
    </div>
    



    <script src="../js/login.js"></script>
</body>
</html>