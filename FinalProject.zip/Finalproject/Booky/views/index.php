<?php include("../dbfonctions.php");
if(isset($_POST["logout"])&& $_POST["logout"] == "ok"){
    DestroyLoginCookie();
    header("location:./index.php");
}
Connection();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/x-icon" href="./imgs/B.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">
    <title>Booky | Index</title>
</head>
<body>
    <div id="king" class="king">
        <div class="menu">
            <div>
                <a href="">
                    <img src="../imgs/logoCarre.png" alt="">
                </a>
            </div>
            
           <?php 
           if(isset($_COOKIE["username"]) && isset($_COOKIE["password"])){
            include("../pageparts/activestatus.php");

           }
           
           ?>
        
             
        </div>

        <div id="main" class="main">
            <form class="search" action="../AJAX/loadPosts.php">
                <i class='searchIcon bx bx-search-alt'></i>
                <input id="searchBar" type="text" name="searchBar" onkeyup="suggestNamesFromInput(this.value)" placeholder="#Taper un username">
            </form>
           <div id="klopp" class="klopp">

                <?php if(isset($_SESSION["uniq"])){ session_unset() ;} else{ShowPosts();} ?>
           </div>
           

                        
            
        </div>

        <div class="auth">
            <div class="authForm" style="<?php if (isset($_COOKIE['username'])) echo "display: none"; ?>">
                <p class="h">Nouveauté sur Booky ?</p>
                <p class="des">Inscrivez-vous pour profiter de votre propre fil personnalisé !</p>
                <form action="#">
                    <div class="signup">
                        <input type="hidden" name="id" value="reda">
                        <a href="./signup.php">Sign Up</a>
                    </div>
                    <div class="logLink">
                        <a href="./login.php"> Already have an account ? </a>
                    </div>
                </form>
            </div>    
        </div>
    </div>

    <script src="../js/index.js"></script>
</body>
</html>