<?php include("../dbfonctions.php");
if(isset($_POST["logout"])&& $_POST["logout"] == "ok"){
    DestroyLoginCookie();
    header("location:./index.php");
}
Connection();
$userID = GetUserId();
$infos = GetInfos($userID);
$postID = $_GET["id_post"];
$req = "SELECT * FROM posts WHERE id_post = $postID";
$result = $conn->query($req);
$row = $result->fetch_assoc();
$oldcontenu = $row["contenu"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/x-icon" href="../imgs/B.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/modify_post.css">
    <title>Booky | Mouad Boufenzi</title>
</head>
<body>
    <div id="king" class="king">
        <div class="menu">
            <div>
                <a href="">
                    <img src="../imgs/logoCarre.png" alt="">
                </a>
            </div>
            <?php include("../pageparts/activestatus.php");?>
        </div>

        <div class="main">
            <div class="back">
                <div class="SignDiv">
                    <i id="backArrow" class='bx bx-left-arrow-alt' ></i>
                </div>
                <div class="SuppInfo">
                    <p class="suppUser"><?php echo $infos["username"]?> <span>| Modifier votre post</span></p>
                </div>
            </div>

            <div class="createDiv">
                <div class="AvatarDiv">
                    <div class="avatar">
                        <img src="<?php echo $infos["avatarURL"]?>" alt="">
                    </div>
                </div>

                <div class="formDiv">
                    <div class="form">
                        <form method= "post" action="../pageparts/modifypost.php?id_post=<?php echo $postID ?>" enctype="multipart/form-data">
                            <textarea class="desc" oninput="autoHeight(this)" name="contenu" placeholder="Partagez vos mots ..."><?php echo $oldcontenu?></textarea>
                            <output></output>

                            <div class="optionsDiv">
                                <div class="options">

                                    <div class="imageOption">
                                        <input class="custom-file-input" type="file" name="file" style="color: white;" accept="image/jpeg, image/png, image/jpg">
                                    </div>
                                    
                                    <div class="checking">
                                        <div class="limit"></div>
                                        <div class="actual"></div>
                                    </div>
                                </div>

                                <div class="button">
                                    <button type="submit" class="sub" id="tay3mer" >Partager</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="auth">
            
        </div>
    </div>

    <script src="../js/modify_post.js"></script>
</body>
</html>