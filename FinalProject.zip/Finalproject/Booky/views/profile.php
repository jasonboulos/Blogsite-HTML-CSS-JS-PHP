<?php 
session_start();
include("../dbfonctions.php");
// include("../pageparts/upload.php");
if(isset($_POST["logout"])&& $_POST["logout"] == "ok"){
    DestroyLoginCookie();
    header("location:./index.php");
}
Connection();
$userID = GetUserId();
if($_GET["userID"]!=$userID){
    $infos = GetInfos($_GET["userID"]);
    $age = UserAge($_GET["userID"]);
}
else{
    $infos = GetInfos($userID);
    $age = UserAge($userID);
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/x-icon" href="../imgs/B.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/profil.css">
    <link rel="stylesheet" href="../css/modify_post.css">
    <title>Booky | Mouad Boufenzi</title>
</head>
<body>
<div id="king" class="king">
        <div class="menu">
            <div>
                <a href="">
                    <img src="../imgs/logoCarre.png" alt="">
                </a>
            </div>

          <?php include("../pageparts/activestatus.php");?>
        </div>

        <div class="main">
            <div class="back">
                <div class="SignDiv">
                    <i id="backArrow" class='bx bx-left-arrow-alt' ></i>
                </div>
                <div class="SuppInfo">
                    <p class="suppUser"><?php echo $infos["username"] ?></p>
                    <p class="suppPosts"><?php echo $infos["nbrPosts"]?> posts</p>
                </div>
            </div>

            <div class="userDiv">
                <div class="picDiv">
                    <div class="pic">
                        <div class="picArea">
                            <img src="<?php echo $infos["avatarURL"]?>" alt="">
                        </div>
                    </div>

                    <div class="userInfo">
                        <p class="user"><?php echo $infos["username"] ?> <span class="age"><?php echo $age?>ans</span></p>
                        <p class="country"><?php echo $infos["pays"]?></p>
                        <p class="quote"><?php echo $infos["bio"] ?></p>
                    </div>
                </div>

                <div class="favDiv">
                    <div class="favAuthor">
                        <div class="infoAuthor">
                            <div class="head">
                                <p>favorite author <i class='bx bxs-pen' ></i> </p>
                            </div>

                            <div class="content">
                                <p><?php echo $infos["favauthor"] ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="favBook">
                        <div class="infoBook">
                            <div class="head">
                                <p>favorite book <i class='bx bxs-book-heart' ></i> </p>
                            </div>

                            <div class="content">
                                <p><?php echo $infos["favbook"] ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
               
                <?php 
                if($_GET["userID"]!=$userID){
                    echo "";
                }
                else{
                ?>
                 <br>
                    <div class="createDiv">
                    <div class="AvatarDiv">
                        <div class="avatar">
                            <img src="<?php echo $infos["avatarURL"]?>" alt="">
                        </div>
                    </div>

                    <div class="formDiv">
                        <div class="form">
                            <form action="../pageparts/upload1.php?userID=<?php echo $_GET["userID"]; ?>" method="post" enctype="multipart/form-data">
                                <textarea class="desc" oninput="autoHeight(this)" id="valuetext" name="contenu" placeholder="Partagez vos mots ..."></textarea>
                                <output></output>

                                <div class="optionsDiv">
                                    <div class="options">
                                        <div class="imageOption">
                                            <input class="custom-file-input" type="file" name="f" style="color: white;" accept="image/jpeg, image/png, image/jpg">
                                        </div>
                                    
                                        <div class="checking">
                                            <div class="limit"></div>
                                            <div class="actual"></div>
                                        </div>
                                    </div>

                                    <div class="button">
                                        <button class="sub" id="tay3mer" type="submit" name="submit">Partager</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="successMessage"><?php
                            if(isset($_SESSION["deletemsg"])){
                                echo $_SESSION["deletemsg"];
                                session_unset();
                            }
                        ?></div>
                    </div>
                </div>
                <br>
                <?php

                }
                 ?>
                
            


            <?php
            if($_GET["userID"]!=$userID){
                ShowProfilePosts($_GET["userID"]);
            }
            else{
                ShowProfilePosts($userID);
                $infos = GetInfos($userID);
                ?>

                <?php
            }
             ?>
            
            
        </div>


        <div class="auth">
            
        </div>
    </div>

    <script src="../js/profil.js"></script>
    <!-- <script src="../js/modify_post.js"></script> -->
</body>
</html>