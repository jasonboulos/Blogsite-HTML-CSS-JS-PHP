<?php

include("../dbfonctions.php");

Connection();

if(isset($_POST["logout"])&& $_POST["logout"] == "ok"){

    DestroyLoginCookie();

    header("location:./index.php");

}

$id_post = $_GET["id_post"];

$nbrComments = Nombre_de_comments($id_post);

$req = "SELECT * FROM posts, users WHERE id_post=$id_post AND posts.author = users.id_user";

$res = $conn->query($req);

$row = $res->fetch_assoc();

$contenu = $row["contenu"];

$id_userr = $row["author"];

$date = $row["datepost"];

$image = $row["imageURL"];

$username_ = $row["nom_user"];

$avatarURL = $row["avatarURL"]

?>

<!DOCTYPE html>

<html lang="eng">

<head>

<meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel="icon" type="image/x-icon" href="./imgs/B.png">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="../css/index.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed&display=swap" rel="stylesheet">

    <title>Booky | Index</title>

</head>

<body>

<div id="king" class="king">

        <div class="menu">

            <div>

                <a href="">

                    <img src="../imgs/logoCarre.png" alt="">

                </a>

            </div>

           

           <?php

           if(isset($_COOKIE["username"]) && isset($_COOKIE["password"])){

            include("../pageparts/activestatus.php");




           }

           

           ?>

       

             

        </div>




        <div id="main" class="main">

                <div class = "head">

                    <div class = "SignDiv">

                        <i id="backArrow" class='bx bx-left-arrow-alt' ></i>




                    </div>

                    <div class = "infopers">

                         

                            <p class = "title">Post de <?php echo $username_ ?></p>




                    </div>




                </div>

 

           <div id="klopp" class="klopp">




                <?php if(isset($_SESSION["uniq"])){ session_unset() ;} else{?>

                <div id="<?php echo $id_post;?>" class="post" >

                    <div class="avatarDiv">

                        <a ><div class="avatar">

                               <img src="<?php echo $avatarURL ?>" alt="">

                            </div>

                        </a>

                    </div>

   

                    <div class="content">

                        <div class="postInfo">

                            <p class="username"><?php echo $username_?> <span>-  <?php echo $date?></span> </p>

   

                            <p class="postDescription">

                            <?php echo $contenu?>

                            </p>

   
                            <?php
                                if ($image) {
                                    ?> <div class="postPic">
                                         <img src="<?php echo $image; ?>" alt="">
                                     </div>
                                     <?php }
                            }
                            ?>
                            
   

                           

                        </div>

   

                        <div class="reactPost">

                            <div class="prince">

                                    <form method="post" action="../pageparts/Likes.php?postID=<?php echo $id_post?>" >

                                        <div class="reactCardLove">

                                            <div class="reactIcon heartDiv">

                                                <button  id="btnLikes" type="submit"><i class='bx bx-heart' ></i></button>

                                                <input type="hidden" name="like" id="hiddenPost" value="<?php echo $id_post?>">

                                            </div>

                                            <div class="desc">

                                                <p id="nbrLikes"><?php

                                                    echo NbLikesPost($id_post);

                                                ?>

                                                </p>

                                            </div>

                                        </div>




                                    </form>

                                <a >

                                <div class="reactCardCmnt">

                                    <div class="cmntDiv reactIcon">

                                        <!-- <form action="./pageparts/getpostID.php?id_post="> -->

                                        <button class="cmntIcon"><i id="cmntIcon" class='bx bx-message-rounded'></i></button>

                                        </form>

                                    </div>

                                    <div class="desc">

                                        <p><?php echo $nbrComments; ?></p>

                                    </div>
                                </div>




                                </a>  

                               

   

                                <div class="reactCardWrite">

                                    <div class="writeDiv reactIcon">

                                        <button class="writeIcon" id="writeIcon"><i class='bx bx-comment-edit'></i></button>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>
                <div class="display" id="display">
                                <div class="cmntTypeDiv">
                                    <div class="profil">
                                        <div class="profileAvatar">
                                            <img src="<?php echo $avatarURL;?>" alt="">
                                        </div>
                                    </div>
                                    <div class="typeCmnt">
                                        <form action="../pageparts/addComment.php?id_post=<?php echo $id_post;?>&pp=true" method="post">
                                            <textarea class="cmntTextarea" id="cmntTextarea" name="msg" placeholder="Laissez un commentaire ..."></textarea> <br>
                                            <button id="submit" class="submit" disabled>Répondre</button>
                                        </form>
                                    </div>
                                </div>
                </div>

               

               

               

               

                <?php




                 ?>

           </div>

           




           <div class="Comments">
                <?php
                    if(ShowComments($id_post)) ShowComments($id_post);
                ?>
           </div>            

           

        </div>

           




        <div class="auth">

           




        </div>

    </div>




    <script src="../js/pagepost.js"></script>

</body>

</html>