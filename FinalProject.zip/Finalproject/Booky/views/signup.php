<?php session_start();
include("../dbfonctions.php");
 Connection();
$newAccountStatus = CheckNewAccountForm();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../imgs/B.png">
    <link rel="stylesheet" href="../css/signup.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Open+Sans&family=Raleway:wght@500&family=Roboto+Slab:wght@500&family=Rubik&family=Ubuntu:ital@0;1&display=swap" rel="stylesheet">
    <title>Booky | Signup</title>
</head>
<body>
    <div id="king" class="king"> 
        <div class="logoDiv">
            <div class="logo">
                <a href="./index.php"><img src="../imgs/logoCarre.png" alt=""></a>
                <p>Your virtual safe <span>place</span> to share your <span>words</span></p>
            </div>
        </div>

        <div class="formDiv">
            <video width="100%" height="99.97%" autoplay muted loop>
                <source src="../imgs/bg3.mp4" type="video/mp4">
                    Your browser does not support the video tag.
            </video>

            <div class="bord c">
			    <div class="title">Créez votre compte!</div>
                <?php  if($newAccountStatus["Successful"]){
                    echo '<h3 class="successMessage">Nouveau compte crée avec succès!</h3>';
                     }
                    elseif (isset($_SESSION['error'])){
                            echo '<h3 class="errorMessage">'.$_SESSION['error'].'</h3>';
                            session_unset();
                     } ?>
			        <form class="form" method="post" style="<?php if($newAccountStatus["Successful"]) echo "display: none";   ?>">
				        <input id="username"type="text" name="username" placeholder="Nom d'utilisateur">
				        <input  id="email" type="email" name="email" placeholder="Email">
				        <input id="mdp"type="password" name="mdp" placeholder="Mot de passe">
                        <input id="mdpc" type="password" name="mdpc" placeholder="Confirmation de mot de passe">
				        <input id="date"type = "date" name="date">
                        <button id="signup-btn" name="k" class="btn" type="submit">Connexion</button>
			        </form>
                    <div class="linkSignup">
                        <a href="./login.php"><?php if($newAccountStatus["Successful"]) {echo "Connectez sur votre espace";}else{ echo "Vous avez déja un compte ?";}  ?></a>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <script src="../js/signup.js"></script>
</body>
</html>