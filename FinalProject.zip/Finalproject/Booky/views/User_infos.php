<?php include("../dbfonctions.php");
if(isset($_POST["logout"])&& $_POST["logout"] == "ok"){
    DestroyLoginCookie();
    header("location:./index.php");
}
Connection();
$userID = GetUserId();
$infos = GetInfos($userID);
$updt = UpdateInfo($userID);
$changepass = ChangePassword($userID);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" type="image/x-icon" href="../imgs/B.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/User_infos.css">
    <title>Booky | Paramètres</title>
</head>

<body>
    <div id="king" class = "king">
        <div class = "menu">
            <div>
                <a href="./index.php">
                    <img src="../imgs/logoCarre.png" alt="">
                </a>
                
            </div>
            <?php include("../pageparts/activestatus.php");?>
           

        </div>
        <div class ="main">
                <div class = "head">
                    <div class = "SignDiv">
                        <i id="backArrow" class='bx bx-left-arrow-alt' ></i>

                    </div>
                    <div class = "infopers">
                         
                            <p class = "title">Paramètre</p>

                        

                    </div>

                </div>
                <div class = "leftsideinfo">
                    <div class = "userimage">
                        <img src="<?php echo  $infos["avatarURL"]?>" alt="user profile image">
                    </div>
                    <div>
                        <form class="Avatarupload"method="post" action="" enctype="multipart/form-data">
                            <label for="image"></label>
                            <input type="file" name="image" class = "imageinput" value="none" accept="image/*" placeholder="none">
                            <input type="submit" value="Upload" name="upload" class = "imageupload">
                        </form>
                    </div>
                    <?php
                        include("../pageparts/uploadAvatar.php");
                    ?>
                </div>
    
                <div class = "informations">
                <?php  if($updt["Successful"]){
                    echo '<h3 class="successMessage">Informations changées avec succès!</h3>';
                     }
                    elseif ($updt["Attempted"]){
                            echo '<h3 class="errorMessage">'.$updt['ErrorMessage'].'</h3>';
                     } ?>
      
                    
                    <form action="" method="post">
                        <h2>INFORMATIONS PERSONNEL</h2>           
                        <div class="form-row">
                            <label for="name">Username:</label>
                            <input type="text" id="name" name="name" value = "<?php echo $infos["username"]?>">
                        
                        </div>
                        <div class="form-row">
                            <label for="email">Email:</label>
                            <input type="text" id="email" name="email" value = "<?php echo $infos["email"]?>">
                        
                        </div>
                       <h2>BIO</h2>
                        <div class="form-row">
                            <label for="titre">Titre</label>
                            <input id="titre" name="titre" type="text" value="<?php echo $infos["bio"]?>">
                        </div>
                        <div class="form-row">
                            <label for="author">Fav author</label>
                            <input id="author" name="author" type="text" value="<?php echo $infos["favauthor"]?>">
                        </div>
                        <div class="form-row">
                            <label for="book">Fav Book</label>
                            <input id="book" name="book" type="text" value="<?php echo $infos["favbook"]?>">

                        </div>
                        <h2>Nationalité</h2>
                        <div class="form-row">
                            <label for="pays">Pays de naissance</label>
                            <input id="pays" name="pays" type="text" value="<?php echo $infos["pays"]?>">
                        </div>
                  
                        <div class="savebtn">
                            <button class="sauvegarder" type = "submit">Sauvegarder</button>

                        </div>  
                       
                    </form>
                    
                    <br>
                    <?php  if($changepass["Successful"]){
                    echo '<h3 class="successMessage">Informations changées avec succès!</h3>';
                     }
                    elseif ($changepass["Attempted"]){
                            echo '<h3 class="errorMessage">'.$changepass['ErrorMessage'].'</h3>';
                     } ?>
      
                
                    <form class="passform" method="post">
                    <h2>MOT DE PASSE</h2>
                        <div class="form-row">
                            <label for="old-password">Old Password:</label>
                            <input type="password" id="old-password" name="old-password" value = "">
                            
                        </div>
                        <div class = "form-row">
                            <label for="new-password">New Password:</label>
                            <input type="password" id="new-password" name="new-password" value = "">
                        </div>

                        <div class = "form-row">
                            <label for="confirm-password">Confirm Password:</label>
                            <input type="password" id="confirm-password" name="confirm-password" value = "">
                        </div>
                        <div class="savebtn">
                            <button class="sauvegarder" type = "submit">Changer</button>

                        </div>  
                    </form>

                </div>

            </div>

    </div>
    <script src = "../js/User_infos.js"></script>
</body>