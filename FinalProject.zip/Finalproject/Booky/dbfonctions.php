<?php
// include 'pageparts/fileupload.php';
$rootpath = "localhost/Booky/views/index.php";
//la fonction qui fait la liason avec database
function Connection(){
    // Create connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "Booky";
    global $conn;
    
    $conn = new mysqli($servername, $username, $password, $dbname);


    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
}

//Function to clean up an user input for safety reasons
//--------------------------------------------------------------------------------
function SecurizeString_ForSQL($string) {
    $string = trim($string);
    $string = stripcslashes($string);
    $string = addslashes($string);
    $string = htmlspecialchars($string);
    return $string;
}

function CheckNewAccountForm(){
    global $conn;

    $creationAttempted = false;
    $creationSuccessful = false;
    $error = NULL;
    //Données reçues via formulaire?
    if(isset($_POST["k"])){
        if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["date"]) && isset($_POST["mdp"]) && isset($_POST["mdpc"])){

            $creationAttempted = true;
            $email =$_POST["email"] ;
            $username = $_POST["username"];
            $query = "SELECT * FROM `users` WHERE email = '$email'";
            $result = mysqli_query($conn,$query);
            $query2 = "SELECT * FROM `users` WHERE nom_user = '$username'";
            $result2 = mysqli_query($conn,$query2);
            
    
            //Form is only valid if password == confirm, and username is at least 4 char long
            if ( strlen($_POST["username"]) < 4 ){
                $error = "Un nom utilisateur doit avoir une longueur d'au moins 4 lettres";
            }
            elseif ( $_POST["mdp"] != $_POST["mdpc"] ){
                $error = "Le mot de passe et sa confirmation sont différents";
            }
            elseif(mysqli_num_rows($result)>0){
                $error = "Email address is already used, please use another email!";
            }
            elseif(mysqli_num_rows($result2)>0){
                $error = "Username is already used, please use another one!";
            }
            else {
                $username = SecurizeString_ForSQL($_POST["username"]);
                $password = md5($_POST["mdp"]);
                $email = SecurizeString_ForSQL($_POST["email"]);
                $birthdate = $_POST["date"];
                
    
                $query = "INSERT INTO `users` VALUES (NULL, '$username','$birthdate','$password','$email', '../imgs/user.png', NULL, NULL, NULL, NULL)";
                $result = $conn->query($query);
                
                
    
                if( mysqli_affected_rows($conn) == 0 )
                {
                    $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                }
                else{
                    $creationSuccessful = true;
                    
                }
                
            }
    
        }else{
            $error = "Vous devez remplir tous les champs !";
            
        }
        $_SESSION['error']=$error;
        $resultArray = ['Attempted' => $creationAttempted, 
                        'Successful' => $creationSuccessful, 
                        'ErrorMessage' => $error];
    
        return $resultArray;
    }else{
        $resultArray = ['Attempted' => $creationAttempted, 
        'Successful' => $creationSuccessful, 
        'ErrorMessage' => $error];

    return $resultArray;
    }
    
}

// Cette fonction permet de mettre à jour les informations d'un utilisateur dans la base de données en fonction des informations envoyées en POST.
// Elle prend en paramètre l'ID de l'utilisateur.
function UpdateInfo($userID){
     // Initialisation des variables
     $creationAttempted = true; // Un indicateur pour savoir si la mise à jour a été tentée
     $creationSuccessful = false; // Un indicateur pour savoir si la mise à jour a réussi
     $oldusername = NULL; // Le nom d'utilisateur existant avant la mise à jour
     $error = NULL; // Un message d'erreur, s'il y a lieu
    global $conn;

      // Vérifier si les champs de formulaire sont définis
    if(isset($_POST["name"])||isset($_POST["email"]) ||isset($_POST["titre"]) ||isset($_POST["author"]) || isset($_POST["book"])|| isset($_POST["pays"]) ){
        // Récupération des valeurs des champs de formulaire
        $username = $_POST["name"];
        $email = $_POST["email"];
        $bio = $_POST["titre"];
        $favauthor = $_POST["author"];
        $favbook = $_POST["book"];
        $pays = $_POST["pays"];
    
    
        if ( strlen($username) < 4 ){
            $error = "Un nom utilisateur doit avoir une longueur d'au moins 4 lettres";
        }
   
      
        else{
            $oldinfos = "SELECT * FROM users WHERE id_user = $userID";
            $resultold = mysqli_query($conn,$oldinfos);
            if($resultold){
                $row = mysqli_fetch_assoc($resultold);
               $oldusername = $row['nom_user'];
               $oldemail = $row['email'];
               $oldbio = $row["bio"];
               $oldfavauthor = $row["fav_author"];
               $oldfavbook = $row["fav_book"];
               $oldpays = $row["pays"];
               if($oldusername != $username){
                $sql = "UPDATE users SET nom_user = '$username' WHERE id_user = $userID";
                $res = $conn->query($sql);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }
                if( mysqli_affected_rows($conn) == 0 )
                {
                    $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                }
                else{
                    $creationSuccessful = true;
                    setcookie("username","$username",time() + 24*3600, '/', 'localhost',false);
        
                }
               }
               if($oldemail!= $email){
                $sql = "UPDATE users SET email = '$email' WHERE id_user = $userID";
                $res = $conn->query($sql);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                    }
                if( mysqli_affected_rows($conn) == 0 )
                {
                    $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                }
                else{
                    $creationSuccessful = true;
                                                

                    }
                 }
                 if($oldbio != $bio){
                    $sql = "UPDATE users SET bio = '$bio' WHERE id_user = $userID";
                     $res = $conn->query($sql);

               
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                        }
                    if( mysqli_affected_rows($conn) == 0 )
                    {
                        $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                    }
                    else{
                        $creationSuccessful = true;
                                                    
    
                   }
                }
                if($oldfavauthor != $favauthor){
                    $sql = "UPDATE users SET fav_author = '$favauthor' WHERE id_user = $userID";
                     $res = $conn->query($sql);

               
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                        }
                    if( mysqli_affected_rows($conn) == 0 )
                    {
                        $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                    }
                    else{
                        $creationSuccessful = true;
                                                    
    
                   }
                }
                if($oldfavbook != $favbook){
                    $sql = "UPDATE users SET fav_book = '$favbook' WHERE id_user = $userID";
                     $res = $conn->query($sql);

               
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                        }
                    if( mysqli_affected_rows($conn) == 0 )
                    {
                        $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                    }
                    else{
                        $creationSuccessful = true;
                                                    
    
                   }
                }
                if($oldpays != $pays){
                    $sql = "UPDATE users SET pays = '$pays' WHERE id_user = $userID";
                     $res = $conn->query($sql);

               
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                        }
                    if( mysqli_affected_rows($conn) == 0 )
                    {
                        $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
                    }
                    else{
                        $creationSuccessful = true;
                                                    
    
                   }
                }

            }

        }
}


    $resultArray = ['Attempted' => $creationAttempted, 
    'Successful' => $creationSuccessful, 
    'ErrorMessage' => $error];

    return $resultArray;
 }

// Cette fonction prend en entrée l'ID de l'utilisateur et retourne un tableau contenant des informations sur la tentative de modification de mot de passe
function ChangePassword($userID){
    // Initialisation des variables de résultat
    $creationAttempted =false;
    $creationSuccessful = false;
    $error = NULL;
    global $conn;
    // Vérification que les champs nécessaires ont été soumis via le formulaire POST
    if(isset($_POST["old-password"])&&isset($_POST["new-password"]) &&isset($_POST["confirm-password"])){
        $creationAttempted = true;// On note que la tentative de modification a été effectuée
       
        // Récupération des champs du formulaire et hashage des mots de passe avec md5
        $oldpassword = md5($_POST["old-password"]);
        $newpassword = md5($_POST["new-password"]);
        $confirmpassword = md5($_POST["confirm-password"]);
        
        // Récupération des champs du formulaire et hashage des mots de passe avec md5
        $query ="SELECT pasword FROM `users` WHERE id_user = '$userID' ";
        
       $result =$conn->query($query);
        if($result){
            $row = mysqli_fetch_assoc($result);
          
        }      // Vérification que l'ancien mot de passe entré correspond à celui stocké en base de données
        if($row['pasword']!=$oldpassword){
            $error= "Old password is wrong!";
            echo 'same';
            
        }      // Vérification que le nouveau mot de passe et sa confirmation correspondent
        elseif($newpassword != $confirmpassword){
            $error = "the new password and it's confirmation are wrong";
            echo "hello";
        }
        else{
            $sql = "UPDATE users SET pasword = '$newpassword' WHERE id_user = $userID ";
            $res = $conn->query($sql);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
                }
            if( mysqli_affected_rows($conn) == 0 )
            {
                $error = "Erreur lors de l'insertion SQL. Essayez un nom/password sans caractères spéciaux";
            }
            else{
                // Si tout s'est bien passé, on note que la modification a été effectuée avec succès et on met à jour le cookie contenant le mot de passe de l'utilisateur
                $creationSuccessful = true;
                setcookie("password", "$newpassword",time() + 24*3600, '/', 'localhost',false);
    
            }
        }

    } // Construction du tableau de résultat et retour de ce tablea
    $resultArray = ['Attempted' => $creationAttempted, 
    'Successful' => $creationSuccessful, 
    'ErrorMessage' => $error];

    return $resultArray;


}
/**
 * Cette fonction a pour but de vérifier si l'utilisateur est connecté en vérifiant les informations de connexion
 * stockées dans les cookies ou soumises via un formulaire de connexion.
 * 
 * la fonction retourne un tableau associatif contenant des informations sur la tentative de connexion et ses résultats:
 * - Successful (bool) : indique si la tentative de connexion a réussi
 * - Attempted (bool) : indique si une tentative de connexion a été effectuée
 * - ErrorMessage (string) : le message d'erreur associé à la tentative de connexion (s'il y en a un)
 * - userID (int) : l'ID de l'utilisateur connecté (s'il y en a un)
 */
function CheckLogin(){
    global $conn, $username;
    global $userID;

    $error = NULL; 
    $loginSuccessful = false;

   
	if(isset($_POST["username"]) && isset($_POST["mdp"])){
		$username = SecurizeString_ForSQL($_POST["username"]);
		$password = md5($_POST["mdp"]);
		$loginAttempted = true;
	}
	
	elseif ( isset( $_COOKIE["username"] ) && isset( $_COOKIE["mdp"] ) ) {
		$username = $_COOKIE["username"];
		$password = $_COOKIE["mdp"];
		$loginAttempted = true;
	}
	else {
		$loginAttempted = false;
	}

   
    if ($loginAttempted){
        $query = "SELECT * FROM `users` WHERE nom_user = '".$username."' AND pasword ='".$password."'";
       
        $result = $conn->query($query);
        
        if ($result->num_rows > 0) {
            // user was found
            $row = $result->fetch_assoc();
            $userID = $row["id_user"];
            CreateLoginCookie($username, $password);
            $loginSuccessful = true;
        } else {
            // user was not found
            $error = "username or password does not exist. Create an account";
        }
        
    }
	
	$resultArray = ['Successful' => $loginSuccessful, 
					'Attempted' => $loginAttempted, 
					'ErrorMessage' => $error,
					'userID' => $userID];

    

    return $resultArray;
}

// Cette fonction CreateLoginCookie crée un cookie pour stocker le nom d'utilisateur et le mot de passe d'un utilisateur connecté.
//  Le cookie est défini avec une durée de vie de 24 heures et est accessible uniquement sur le domaine "localhost".
function CreateLoginCookie($username, $password){
    setcookie("username", $username, time() + 24*3600, '/', 'localhost',false );
    setcookie("password", $password, time() + 24*3600, '/', 'localhost', false);
 
}



/**
 * Récupère les informations d'un utilisateur à partir de son ID
 *
 * paramétre $userID - ID de l'utilisateur dont on veut récupérer les informations
 * Return - Tableau associatif contenant les informations de l'utilisateur ou null si l'utilisateur n'est pas trouvé
 */

function GetInfos($userID){
    global $conn;
    //Pour calculer le nombre de post de l'utilisateur;
    $nbrPosts = "SELECT COUNT(*) as nbrPosts FROM posts WHERE author = $userID";
    $resultnbrPosts = $conn->query($nbrPosts);
    $rowN = $resultnbrPosts->fetch_assoc();
    $resnbrposts = $rowN["nbrPosts"];
    $resultarray = NULL;
    $req = "SELECT * from`users` WHERE id_user ='".$userID."' ";
    $result = $conn->query($req);
    if ($result->num_rows > 0){
        $row = $result->fetch_assoc();
        $username = $row["nom_user"];
        $email = $row["email"];
        $password = $row["pasword"];
        $birthdate = $row["birthdate"];
        $avatarurl = $row["avatarURL"];
        $favbook = $row["fav_book"];
        $favauthor = $row["fav_author"];
        $bio = $row["bio"];
        $pays = $row['pays'];
        // On stocke les informations de l'utilisateur dans un tableau associatif
        $resultarray =['username'=> $username,
                        'email'=> $email,
                        'password' => $password,
                        'birthdate' => $birthdate,
                        'avatarURL' => $avatarurl,
                        'favbook'=> $favbook,
                        'favauthor'=>$favauthor,
                        'bio'=> $bio,
                    'pays'=>$pays,
                    'nbrPosts' => $resnbrposts];
         

    }
    // On retourne le tableau contenant les informations de l'utilisateur ou null si l'utilisateur n'a pas été trouvé
    return $resultarray;
    

}

// Cette fonction affiche les publications d'un utilisateur en fonction de son ID. Elle se connecte à la base de données pour récupérer les publications de l'utilisateur et les affiche 
// dans une boucle while. Pour chaque publication, elle récupère le contenu, l'image, l'avatar de l'utilisateur, le nom d'utilisateur, la date de publication, le nombre de commentaires et 
// l'ID de la publication. Ensuite, elle affiche ces informations dans une structure HTML pour 
// afficher chaque publication avec son contenu, son image et les informations de l'utilisateur qui l'a publiée. En outre, elle permet à l'utilisateur de modifier ou de supprimer la publication,
//  ainsi que de commenter et de liker la publication.

function ShowProfilePosts($userID){
    global $conn;
    $req = "SELECT * FROM `posts`, `users` where users.id_user = posts.author and posts.author ='".$userID."' ORDER BY id_post DESC ";
    $result = $conn->query($req);
    if ($result->num_rows > 0){
        while( $row = $result->fetch_assoc() ){
            $contenu = $row["contenu"];
            $image = $row["imageURL"];
            $avatar = $row["avatarURL"];
            $username = $row["nom_user"];
            $date = $row["datepost"];
            // $now = CURRENT_TIMESTAMP();
            $id_post = $row["id_post"];
            $nbrMSG = Nombre_de_comments($id_post);
           

            // Calcul du temps écoulé depuis la publication en heures
            $tempsEcouleEnSecondes = time() - strtotime($date);
            $tempsEcouleEnHeures = round($tempsEcouleEnSecondes / 3600);
        ?>
 
        <div class="post">
            <div class="avatarDiv">
                <a href="">
                    <div class="avatar">
                        <img src="<?php echo $avatar?>" alt="">
                    </div>
                </a>

                <div class="postOptions">
                <a href="./modify_post.php?id_post=<?php if(isset($id_post)) {echo $id_post;}?>">
                <div class="modifOp" value="id">
                    
                        <i class='bx bxs-edit editIcon'></i> 
                    </div></a>
                    <a href="../pageparts/deletePost.php?id_post=<?php echo $id_post;?>">
                    <div class="suppOp" id="ii">
                      <i  class='bx bxs-trash suppIcon'></i> 
                    </div></a>
                </div>
            </div>
    
            <div class="contentPost">
                <div class="postInfo">
                    <div class="postClick" value="id_post">
                        <p class="username"><?php echo $username?> <span>- Il y a <?php echo $tempsEcouleEnHeures?>h</span> </p>
    
                        <p class="postDescription">
                            <?php echo $contenu?>
                        </p>

                        <?php
                                if ($image) {
                                   ?> <div class="postPic">
                                        <img src="<?php echo $image; ?>" alt="">
                                    </div>
                                    <?php }
                            
                            ?>
                        
                        
                    </div>

                    <div class="display">
                        <div class="cmntTypeDiv">
                            <div class="profil">
                                <div class="profileAvatar"></div>
                            </div>
                            <div class="typeCmnt">
                                <form action="../pageparts/addComment.php?id_post=<?php echo $id_post;?>">
                                    <textarea class="cmntTextarea" name="" placeholder="Laissez un commentaire ..."></textarea> <br>
                                    <button class="submit"  >Répondre</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    
                <div class="reactPost" >
                    <div class="prince">
                     <form method="post" action="../pageparts/Likes.php?postID=<?php echo $id_post?>&location=profile&userID=<?php echo $userID?>" >
                                <div class="reactCardLove">
                                    <div class="reactIcon heartDiv">
                                        <button type="submit"><i class='bx bx-heart' ></i></button>
                                        <input type="hidden" name="like" >
                                    </div>
                                    <div class="desc">
                                        <p><?php echo NbLikesPost($id_post)?></p>
                                    </div>
                                </div>

                            </form>
                    <!-- <a href="./pagepost.php?id_post=<?php echo $id_post;?>" style="color: black; text-decoration: none; font-weight: 800" > -->
                        <div class="reactCardCmnt">
                            <div class="cmntDiv reactIcon">
                                <a href="./pagepost.php?id_post=<?php echo $id_post;?>" style="color: black; text-decoration: none; font-weight: 800"><i id="cmntIcon" class='bx bx-message-rounded'></i></a>
                            </div>
                            <div class="desc">
                                <p><?php echo $nbrMSG;?></p>
                            </div>
                        </div>
                    <!-- </a> -->
                    </div>
                </div>
            </div>
        </div>
        
     
           <?php }
    }
    
}
?>
<?php
// Cette fonction retourne le nombre de likes pour un post donné. Prend comme parametre l'id du poste.
function NbLikesPost($postID){
    global $conn;

     // Requête pour récupérer le nombre total de likes pour le post spécifié
    $req = "SELECT SUM(nblikes) as num_likes FROM likes WHERE id_post = $postID";
    $res = $conn->query($req);
    $row = $res->fetch_assoc();

    // Récupération du nombre de likes à partir du résultat
    $nblikes = $row["num_likes"];
    if($nblikes == NULL){
        return 0;
    }
    return $nblikes;


}
//fonction qui affiche toutes les commentaires d'un poste, prend en parametre l'id du poste.
function ShowComments($id_post){

 global $conn;

// On sélectionne tous les messages associés à l'id du post en question    
 $req = "SELECT * FROM messages WHERE post=$id_post ORDER BY date_msg";
    
 $res = $conn->query($req);
    

// Si des messages ont été trouvés
 if($res->num_rows > 0 ){
    
   while($row = $res->fetch_assoc()){
     // On récupère le contenu du message et la date
    $message = $row["contenu"];
    $date = $row["date_msg"];
    $iduser = $row["author"];
    // Calcul du temps écoulé depuis la publication en heures
    $tempsEcouleEnSecondes = time() - strtotime($date);
    $tempsEcouleEnHeures = round($tempsEcouleEnSecondes / 3600);
    
    // On cherche le nom de l'utilisateur qui a écrit le message et son image avatar.
    $sql = "SELECT * FROM users WHERE id_user = $iduser";
    
    $query = $conn->query($sql);
    
    $row1 = $query->fetch_assoc();
    
    $username = $row1["nom_user"];
    
    $userimg= $row1["avatarURL"];
    // On affiche les informations 
    ?>

    
    
    <div class="message-container">
        <div>
            <img src="<?php echo $userimg?>" alt="Avatar" class="message-avatar">
        </div>
        <div class="message-content">
            <div class = "message-header">
                <p class="message-username"><?php echo $username?> <span class="message-time">-  Il y a <?php echo $tempsEcouleEnHeures?>h</span></p>
            </div>
            <div class="message-message"><?php echo $message ?></div>
        </div>
    </div>
    
    
    
    
    <?php
    
    
    
    
    
   
    
   }
    
 }else{
   ?> 
        <div class="successMessage">
            Pas de commentaire pour ce post.
        </div>
   <?php
 }
    
    }

//Cette fonction  est utilisée pour afficher tous les posts existants.
function ShowPosts(){
    global $conn;
    // variable $userIDava qui est obtenue à partir de la fonction GetUserId()
    $userIDava = GetUserId();

    //et vérifie si elle est définie. Si elle l'est, elle récupère l'URL de l'avatar de l'utilisateur actuellement connecté.
    if ($userIDava) {
        $resulava = "SELECT avatarURL from users where id_user = $userIDava";
        $resultava = $conn->query($resulava);
        $rowava = $resultava->fetch_assoc();
        $imageAVA = $rowava["avatarURL"];
    }
    // $id_post =$_SESSION["id_post"];
    // $reqComments = "SELECT * FROM messages where post = $id_post and author = ";

    //requête pour récupérer toutes les données de la table "posts" et "users" où l'ID de l'utilisateur correspond à l'ID de l'auteur d'un post.
    $req = "SELECT * FROM `posts`, `users` where users.id_user = posts.author";
    $result = $conn->query($req);
    if ($result->num_rows > 0){
        
        while( $row = $result->fetch_assoc() ){
            $contenu = $row["contenu"];
            $avatar = $row["avatarURL"];
            $image = $row["imageURL"];
            $username = $row["nom_user"];
            $date = $row["datepost"];
            $userID = $row["id_user"];
            $id_post = $row["id_post"];

            // nombre de commentaires sur chaque post en appelant la fonction Nombre_de_comments().
            $nbrMSG = Nombre_de_comments($id_post);

            // Calcul du temps écoulé depuis la publication en heures
            $tempsEcouleEnSecondes = time() - strtotime($date);
            $tempsEcouleEnHeures = round($tempsEcouleEnSecondes / 3600);

        ?>
            <div id="<?php echo $id_post;?>" class="post" >
                    <div class="avatarDiv">
                        <a href="<?php if(isset($_COOKIE["username"])) {echo "./profile.php?userID=$userID" ;}else {echo "login.php";} ?>"><div class="avatar">
                               <img src="<?php echo $avatar?>" alt=""> 
                            </div>
                        </a>
                    </div>
    
                    <div class="content">
                        <div class="postInfo">
                            <p class="username"><?php echo $username?> <span>-  Il y a <?php echo $tempsEcouleEnHeures?>h</span> </p>
    
                            <p class="postDescription">
                            <?php echo $contenu?>
                            </p>
    
                            <?php
                                if ($image) {
                                   ?> <div class="postPic">
                                        <img src="<?php echo $image; ?>" alt="">
                                    </div>
                                    <?php }
                            
                            ?>
    
                            <div class="display">
                                <div class="cmntTypeDiv">
                                    <div class="profil">
                                        <div class="profileAvatar"><img src="<?php echo $imageAVA;?>" alt=""></div>
                                    </div>
                                    <div class="typeCmnt">
                                        <form action="../pageparts/addComment.php?id_post=<?php echo $id_post;?>" method="post">
                                            <textarea class="cmntTextarea" name="msg" placeholder="Laissez un commentaire ..."></textarea> <br>
                                            <button class="submit" disabled>Répondre</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
    
                        <div class="reactPost">
                            <div class="prince">
                                    <form method="post" action="../pageparts/Likes.php?postID=<?php echo $id_post?>" >
                                        <div class="reactCardLove">
                                            <div class="reactIcon heartDiv">
                                                <button  id="btnLikes" type="submit"><i class='bx bx-heart' ></i></button>
                                                <input type="hidden" name="like" id="hiddenPost" value="<?php echo $id_post?>">
                                            </div>
                                            <div class="desc">
                                                <p id="nbrLikes" style="text-decoration: none; font-weight: 700"><?php 
                                                    echo NbLikesPost($id_post);
                                                ?>
                                                </p>
                                            </div>
                                        </div>

                                    </form>
                                   
                                <a style="color: black; text-decoration: none; font-weight: 800" href="<?php if(isset($_COOKIE["username"])) { echo "./pagepost.php?id_post=$id_post"; } else { echo "./login.php"; } ?>">
                                    <div class="reactCardCmnt">
                                        <div class="cmntDiv reactIcon">
                                            <!-- <form action="./pageparts/getpostID.php?id_post=<?php //echo $id_post;?>"> -->
                                            <button class="cmntIcon"><i id="cmntIcon" class='bx bx-message-rounded'></i></button>
                                            <!-- </form> -->
                                        </div>
                                        <div class="desc">
                                            <p><?php
                                                    echo $nbrMSG;
                                                ?></p>
                                        </div>
                                    </div>
    
                                </a>
                                <div class="reactCardWrite">
                                    <div class="writeDiv reactIcon">
                                        <button class="writeIcon"><i class='bx bx-comment-edit'></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>

       
           
         
<?php
        }
        

    }
}

// Cette fonction récupère l'identifiant de l'utilisateur à partir des cookies de connexion
// Return: l'identifiant de l'utilisateur ou NULL si les cookies ne sont pas définis ou si l'utilisateur n'existe pas
function GetUserId(){
    $userID = NULL ;
    global $conn;
    
     // Vérifie si les cookies "username" et "password" sont définis
    if(isset($_COOKIE['username']) && isset($_COOKIE["password"])){
        $usern = $_COOKIE['username'];
       
        // Requête SQL pour récupérer l'identifiant de l'utilisateur correspondant au nom d'utilisateur dans le cookie
        $req = "SELECT id_user FROM `users` WHERE nom_user = '".$usern."' ";
        $result = $conn->query($req);
         // Si l'utilisateur existe, récupère son identifiant et le retourne
        if ($result->num_rows > 0){
            $row = $result->fetch_assoc();
            $userID = $row["id_user"];
            return $userID;
        }

    }
    return NULL;
    
 }

// function createPost($userID){
//     global $conn;
//     $creationAttempted = false;
//     $creationSuccessful = false;
//     $error = NULL;

//     if(isset($_POST["contenu"])){
//         $contenu = $_POST["contenu"];
//         echo "hello";
//         $req = "INSERT into 'posts' VALUES (null, $userID, $contenu, NULL, NULL)";
//         $result = $conn->query($req);
//         if($result){
//             $creationAttempted = true;
//             $creationSuccessful = true;
//         }else{
//             $creationAttempted = true;
//             $error = "Connection DB";
//         }

//         $img = new ImgFileUploader($SQLconn);

//         $req1 = "SELECT posts.id_post FROM posts WHERE author = $userID ORDER BY datepost ASC LIMIT 1";
//         $result1 = $conn->query($req1);
        

//         // $id_post = $result1->fetch_assoc()[0]["id_post"];

//         if ($result1->num_rows > 0){
        
//             while( $row = $result1->fetch_assoc() ){
//                 $id_post = $row["id_post"];
//             }
//         }
        

//         $img->SaveFileAsNew( $id_post );
//         $creationSuccessful = !$img->errorText && $creationSuccessful;

//         $creationSuccessful = true;
//     }else{
//         $error = "Erreur d'insertion";
//     }

//     return $results = ['succes' => $creationSuccessful,
//                     'error'=> $error];
// }


// Cette fonction supprime les cookies de connexion en utilisant la fonction setcookie()
 function DestroyLoginCookie(){
    setcookie("username", NULL, -1  ,'/', 'localhost',false);
    setcookie("password", NULL, -1, '/', 'localhost',false);
}


// Cette fonction calcule l'âge d'un utilisateur à partir de son ID
// $userID: l'identifiant de l'utilisateur pour lequel on souhaite calculer l'âge
// Return: l'âge de l'utilisateur en années
function UserAge($userID){
    global $conn;

     // Requête SQL pour récupérer la date de naissance de l'utilisateur
    $req = "SELECT birthdate FROM users where id_user = $userID ";

      // Exécute la requête et récupère le résulta
    $res = $conn->query($req);

    // Récupère la date de naissance de l'utilisateur depuis le résultat de la requête
    $row = mysqli_fetch_assoc($res);
    
      // Calcule l'âge de l'utilisateur en années en soustrayant sa date de naissance de la date actuelle
    $birthdate = $row["birthdate"];
    $age = floor((time() - strtotime($birthdate)) / (365 * 24 * 60 * 60));

      // Retourne l'âge de l'utilisateur sous forme de chaîne de caractères
    return strval($age);
}


// Cette fonction récupère le nombre de commentaires pour un post donné
// $id_post: l'identifiant du post pour lequel on souhaite récupérer le nombre de commentaires
// Return: le nombre de commentaires pour le post donné

function Nombre_de_comments($id_post){
    global $conn; 

     // Requête SQL pour compter le nombre de commentaires pour le post donné
    $reqnbr = "SELECT COUNT(*) as Nombre_de_message FROM messages WHERE post=$id_post ";

     // Exécute la requête et récupère le résultat
    $resnbr = $conn->query($reqnbr);
    
     // Vérifie s'il y a des résultats dans le résultat de la requête
    if($resnbr->num_rows){
        // Boucle sur chaque résultat et récupère le nombre de commentaires
        while($row = $resnbr->fetch_assoc()){
        $nbrMSG = $row["Nombre_de_message"];
        }


        // Retourne le nombre de commentaires
        return $nbrMSG;
    }

    
}