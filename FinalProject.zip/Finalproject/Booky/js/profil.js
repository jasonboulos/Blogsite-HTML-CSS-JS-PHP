// Définition de variables
let king = document.getElementById("king")
let height = window.innerHeight
let backArrow = document.getElementById("backArrow")

let LoveDiv = document.querySelectorAll(".reactCardLove")
let LoveIcon = document.querySelectorAll(".heartDiv")

let CmntDiv = document.querySelectorAll(".reactCardCmnt")

let writeDiv = document.querySelectorAll(".reactCardWrite")

let cmntIcons = document.querySelectorAll(".writeIcon")
let typeDiv = document.querySelectorAll(".display")

let cmntTextareas = document.querySelectorAll(".cmntTextarea")
let subBtns = document.querySelectorAll(".submit")

let posts = document.querySelectorAll(".postClick")

let home = document.getElementById("home")

let modifs = document.querySelectorAll(".modifOp")
let supps = document.querySelectorAll(".suppOp")

let desc = document.querySelector(".desc")

let btn = document.querySelector(".sub")


king.style.height = `${height}px`

document.querySelector(".crePost").addEventListener('click', () => {
    window.location.href = "./modify_post.php"
})

// document.getElementById("profile").addEventListener('click', () => {
//     window.location.href = "./profile.php?" + document.getElementById("profile").attributes[2].value
// })

modifs.forEach(modif => {
    modif.addEventListener('mouseover', () => {
        modif.style.background = "rgb(134, 213, 255)"
        modif.childNodes[1].style.color =  "white"
    })

    modif.addEventListener('mouseleave', () => {
        modif.style.background = "transparent"
        modif.childNodes[1].style.color = "black"
    })

   
})

supps.forEach(supp => {
    supp.addEventListener('mouseover', () => {
        supp.style.background = "rgb(255, 100, 95)"
        supp.childNodes[1].style.color = "white"
    })

    supp.addEventListener('mouseleave', () => {
        supp.style.background = "transparent"
        supp.childNodes[1].style.color = "black"
    })
})



backArrow.addEventListener('click', () => {
    history.back();
})

LoveDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(13, 203, 86)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(13, 203, 86)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
});

CmntDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(17, 105, 142)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(17, 105, 142)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
})

writeDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(106, 106, 106)"
        div.childNodes[1].childNodes[1].style.color = "white"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
    })
})

for (let i = 0; i < subBtns.length; i++) {
    cmntTextareas[i].addEventListener('keyup', () => {
        if (cmntTextareas[i].value) {
            subBtns[i].removeAttribute("disabled")
        } else {
            subBtns[i].setAttribute("disabled", "")
        }
    })
}

home.addEventListener('click', () => {
    window.location.href = "../index.php"
})

let max = 5000
desc.addEventListener('keyup', () => {
    let actSize = desc.value.toString().length
    console.log(actSize)
    if (actSize != 0 && actSize <= max) {
        btn.style.display = "block"
    } else if (actSize > max) {
        btn.style.display = "none"
    } else if (actSize == 0) {
        btn.style.display = "none"
    }
})

// var tay3mer = document.getElementById("tay3mer")
// var textarea = document.getElementById("valuetext")
// var valuetext = document.getElementById("valuetext").value

// textarea.addEventListener("input", function(){
//     if(valuetext == ""){
//         tay3mer.disabled = true;
//     }
// })


document.getElementById("ii").addEventListener("click", function () {
    alert("Suppression effectué")
  })