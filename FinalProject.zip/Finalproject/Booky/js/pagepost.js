// Définition de variables
let screenHeight = window.innerHeight
let king = document.getElementById("king")
let main = document.getElementById("main")
let deleteIcon = document.getElementById("delete")
let backArrow = document.getElementById("backArrow")

let LoveDiv = document.querySelectorAll(".reactCardLove")
let LoveIcon = document.querySelectorAll(".heartDiv")

let CmntDiv = document.querySelectorAll(".reactCardCmnt")

let writeDiv = document.querySelectorAll(".reactCardWrite")

let cmntIcons = document.getElementById("writeIcon")
let typeDiv = document.getElementById("display")

let cmntTextareas = document.getElementById("cmntTextarea")
let subBtns = document.getElementById("submit")

// Réglage de la hauteur du roi
king.style.height = `${screenHeight}px`

// Événements pour les réactions "J'aime"
LoveDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(13, 203, 86)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(13, 203, 86)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
});

// Événements pour les réactions "Commenter"
CmntDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(17, 105, 142)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(17, 105, 142)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
})

// Événements pour l'icône "Écrire un commentaire"
writeDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(106, 106, 106)"
        div.childNodes[1].childNodes[1].style.color = "white"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
    })
})

cmntIcons.addEventListener('click', () => {
    typeDiv.style.display = "block"
})

cmntTextareas.addEventListener('keyup', () => {
    if (cmntTextareas.value != "") {
        subBtns.removeAttribute("disabled")
    } else {
        subBtns.setAttribute("disabled", "")
    }
})

//Variable globale
previousText = "";
// document.getElementById("suggestions").innerHTML = "";
timer = 0;

//Timer qui boucle toutes les secondes pour changer la variable globale
function TimerIncrease() {
  timer+=1000;
  setTimeout('TimerIncrease()',1000);
}
TimerIncrease();

function suggestNamesFromInput(currentText) {
   
  if (currentText != previousText && timer >= 1000 ){
    const xhttp = new XMLHttpRequest();
    document.getElementById("klopp").innerHTML = "";
    
    xhttp.onload = function() {      
      document.getElementById("klopp").innerHTML += this.responseText; 
      }
    xhttp.open("GET", "../AJAX/loadPosts.php?var=" + currentText , true); //Le booléen final dit si le chargement est asynchrone ou non
    xhttp.send();

    previousText = currentText;
    timer = 0;
  }
  
}

//On crée une fonction "autoFillName" qui prend en paramètre "nametext". 
//Cette fonction met à jour la valeur de l'élément HTML avec l'ID "searchBar" avec la valeur de "nametext"
function autoFillName(nametext) {
  document.getElementById("searchBar").value = nametext;
}

backArrow.addEventListener('click', () => {
    history.back();
})