// Définition de variables
let screenHeight = window.innerHeight
let king = document.getElementById("king")
let main = document.getElementById("main")
let searchBar = document.getElementById("searchBar")
let deleteIcon = document.getElementById("delete")

let LoveDiv = document.querySelectorAll(".reactCardLove")
let LoveIcon = document.querySelectorAll(".heartDiv")

let CmntDiv = document.querySelectorAll(".reactCardCmnt")

let writeDiv = document.querySelectorAll(".reactCardWrite")

let cmntIcons = document.querySelectorAll(".writeIcon")
let typeDiv = document.querySelectorAll(".display")

let cmntTextareas = document.querySelectorAll(".cmntTextarea")
let subBtns = document.querySelectorAll(".submit")

// Réglage de la hauteur du roi
king.style.height = `${screenHeight}px`

// Événements de la barre de recherche
searchBar.addEventListener('mouseover', () => {
    searchBar.setAttribute("placeholder", "")
})

searchBar.addEventListener('mouseleave', () => {
    searchBar.setAttribute("placeholder", "#UTBM")
})

// Événements pour les réactions "J'aime"
LoveDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(13, 203, 86)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(13, 203, 86)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
});

// Événements pour les réactions "Commenter"
CmntDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(17, 105, 142)"
        div.childNodes[1].childNodes[1].style.color = "white"
        div.childNodes[3].style.color = "rgb(17, 105, 142)"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
        div.childNodes[3].style.color = ""
    })
})

// Événements pour l'icône "Écrire un commentaire"
writeDiv.forEach(div => {
    div.addEventListener('mouseover', () => {
        div.childNodes[1].style.background = "rgb(106, 106, 106)"
        div.childNodes[1].childNodes[1].style.color = "white"
    })

    div.addEventListener('mouseleave', () => {
        div.childNodes[1].style.background = ""
        div.childNodes[1].childNodes[1].style.color = "black"
    })
})

// Affichage/masquage de la zone de saisie de commentaire
let count = 0
typeDiv.forEach(sec => {
    cmntIcons[count].addEventListener('click', () => {
        typeDiv.forEach(sec => {
            if (sec.style.display == "block") sec.style.display = "none"
        })

        if (sec.style.display === "block") {
            sec.style.display = "none"
        } else {
            sec.style.display = "block"
        }
    })
    count++
})

//On boucle sur tous les éléments stockés dans "subBtns" et on ajoute un événement "keyup" 
//sur chaque "cmntTextarea". Lorsque l'utilisateur tape sur le clavier, si le champ de texte n'est pas vide, 
//on supprime l'attribut "disabled" du bouton de soumission correspondant. 
//Sinon, on ajoute l'attribut "disabled"
for (let i = 0; i < subBtns.length; i++) {
    cmntTextareas[i].addEventListener('keyup', () => {
        if (cmntTextareas[i].value) {
            subBtns[i].removeAttribute("disabled")
        } else {
            subBtns[i].setAttribute("disabled", "")
        }
    })
}

//Variable globale
previousText = "";
// document.getElementById("suggestions").innerHTML = "";
timer = 0;

//Timer qui boucle toutes les secondes pour changer la variable globale
function TimerIncrease() {
  timer+=1000;
  setTimeout('TimerIncrease()',1000);
}
TimerIncrease();

function suggestNamesFromInput(currentText) {
   
  if (currentText != previousText && timer >= 1000 ){
    const xhttp = new XMLHttpRequest();
    document.getElementById("klopp").innerHTML = "";
    
    xhttp.onload = function() {      
      document.getElementById("klopp").innerHTML += this.responseText; 
      }
    xhttp.open("GET", "../AJAX/loadPosts.php?var=" + currentText , true); //Le booléen final dit si le chargement est asynchrone ou non
    xhttp.send();

    previousText = currentText;
    timer = 0;
  }
  
}

//On crée une fonction "autoFillName" qui prend en paramètre "nametext". 
//Cette fonction met à jour la valeur de l'élément HTML avec l'ID "searchBar" avec la valeur de "nametext"
function autoFillName(nametext) {
  document.getElementById("searchBar").value = nametext;
}

