// On récupère la hauteur de la fenêtre du navigateur
let screenHeight = window.innerHeight
// On récupère l'élément du DOM avec l'identifiant "container"
let container = document.getElementById("container")

// On définit la hauteur du conteneur en pixels pour qu'elle soit égale à la hauteur de la fenêtre du navigateur
container.style.height = `${screenHeight}px`