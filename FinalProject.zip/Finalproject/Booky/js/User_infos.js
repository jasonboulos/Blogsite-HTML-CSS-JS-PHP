let backArrow = document.getElementById("backArrow");
backArrow.addEventListener('click', () => {
    history.back();
})
