let desc = document.querySelector(".desc")
let check = document.querySelector(".checking")
let actual = document.querySelector(".actual")
let btn = document.querySelector(".sub")
const input = document.querySelector("input")
const output = document.querySelector("output")
let king = document.getElementById("king")
let height = window.innerHeight



// Dimensionnement de la div king pour qu'elle occupe la hauteur de l'écran
king.style.height = `${height}px`

// Ajout d'un écouteur d'événement pour le bouton de retour en arrière
backArrow.addEventListener('click', () => {
    history.back();
})

// Fonction pour ajuster la hauteur de la zone de texte automatiquement
function autoHeight(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = textarea.scrollHeight + 'px';
}

// Définition de la taille maximale de la zone de texte
let max = 2000
desc.addEventListener('keyup', () => {
    // Ajout d'un écouteur d'événement pour la zone de texte
    let actSize = desc.value.toString().length
    // Affichage du bouton de soumission et du compteur de caractères
    if (actSize != 0 && actSize <= max) {
        btn.style.display = "block"
        check.style.display = "block"
        actual.style.width = `${actSize + 1}px`
        actual.style.border = `2px solid rgb(110, 255, 175)`
        // Changement de couleur de la bordure si on atteint la limite
        if (actSize >= max - 20 && actSize <= max) {
            actual.style.border = `2px solid yellow`
        }
    // Masquage du bouton de soumission et du compteur de caractères si la zone de texte est vide
    } else if (actSize > max) {
        actual.style.width = `150px`
        actual.style.border = `2px solid red`
        btn.style.display = "none"
    // Affichage d'une bordure rouge et masquage du bouton de soumission si la limite de caractères est dépassée
    } else if (actSize == 0) {
        check.style.display = "none"
        btn.style.display = "none"
    }
})