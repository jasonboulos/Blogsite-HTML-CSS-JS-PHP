let king = document.getElementById("king")
let height = window.innerHeight

king.style.height = `${height}px`